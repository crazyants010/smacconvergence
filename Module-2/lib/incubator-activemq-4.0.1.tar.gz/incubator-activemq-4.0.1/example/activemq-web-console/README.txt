
Welcome to the ActiveMQ Web Console

To run the console you must install a recent distro of Maven
such as version 2.0.4 or later
	
		http://maven.apache.org/

You can then run the ActiveMQ Web Console via the following command.

	mvn jetty6:run

